
import Head from 'next/head'
import {Row, Col , Icon ,Breadcrumb,Affix, Button, Divider,Tag  } from 'antd'

import Header from '@/components/Header'
import React,{useState} from "react"
import Author from '@/components/Author'
import Footer from '@/components/Footer'
import MarkNav from 'markdown-navbar';
import axios from 'axios'
import { useRouter } from 'next/router'
import { marked } from 'marked'
import hljs from 'highlight.js'
import { FloatButton } from 'antd';
import { QuestionCircleOutlined, SyncOutlined } from '@ant-design/icons';



function Detailed({article}){



  const renderer = new marked.Renderer();

  marked.setOptions({
      renderer: renderer, 
      gfm: true,
      pedantic: false,
      sanitize: false,
      tables: true,
      breaks: false,
      smartLists: true,
      smartypants: false,
      highlight: function (code) {
              return hljs.highlightAuto(code).value;
      }
    }); 


    let html=marked(article.content)
    let htmlIntroduce=marked(article.introduce);
    const routes=useRouter();


    let kindKey;
    if(article.type_id=="技术分享")
    {
      kindKey=1;
    }else if(article.type_id=="前端学习"){
      kindKey=2;
    }
    else if(article.type_id=="生活分享"){
      kindKey=3;
    }
    else if(article.type_id=="更多探索"){
      kindKey=4;
    }


    const colorArr=["#87d068","#f50","#2db7f5","#108ee9"];

    return (
        <>
          <Head>
            <title>峰哥博客&nbsp;&nbsp;{article.title}</title>
          </Head>
          <Header />
          <div className="bread-div">
                <Breadcrumb>
                  <Breadcrumb.Item>
                      <Button type='text' size='small' onClick={()=>routes.push("/")}>首页</Button>
                  </Breadcrumb.Item>
                  <Breadcrumb.Item>
                      <Button type='text' size='small' onClick={()=>routes.push("/list?kind="+kindKey+"&column=所有专栏")}>{article.type_id}列表</Button>
                  </Breadcrumb.Item>
                  <Breadcrumb.Item>
                      <Button type='text' size='small'>{article.title}</Button>
                  </Breadcrumb.Item>
                </Breadcrumb>
              </div>
      <div className='content-mid'>
        <div className='left detailNoneWhite'>
            <div className='content-topDetail'>
              <div className='topTitle'>{article.title}</div>
              <div className='topInfo'>
                <span>文章类型：{article.type_id}</span>
                <span>阅读：{article.viewcount}</span>
                <span>更新于：{article.addtime}</span>
              </div>
              <div className='topInfo'>
                <span>文章标签：
                {article.tags.map((value,index2)=>{
                      return <Tag color={colorArr[index2]} size="large" key={index2}>{value}</Tag>
                    })}
                </span>
              </div>
              <Divider plain>文章简介</Divider>
              <div className='topIntroduce' dangerouslySetInnerHTML={{__html:htmlIntroduce}}>
              </div>
            </div>
            <div className="show-html" dangerouslySetInnerHTML={{__html:html}}>
            </div>
        </div>
        <div className='right'>
          <Author/>
          {/* <Advert/> */}
          <Affix offsetTop={5}>
                <div className="affix1">
                    <div className="nav-title">文章目录</div>
                    <MarkNav className="article-menu" source={article.content} ordered={false}/>
                </div>
            </Affix>
        </div>
      </div>
      <FloatButton.Group shape="square" style={{right: 28,}}>
        <FloatButton icon={<QuestionCircleOutlined />} />
        <FloatButton />
        <FloatButton icon={<SyncOutlined />} />
        <FloatButton.BackTop visibilityHeight={0} />
      </FloatButton.Group>
      <Footer/>
    
       </>
      )
}

Detailed.getInitialProps = async (context) => {
  // const res = await fetch('https://api.github.com/repos/vercel/next.js')
  // const show = await res.json()

  let res=await axios(`http://101.42.225.134:7001/default/getArticleDetail?id=${context.query.id}`);
  // const data = await res.json()
  return {article:res.data};
}

export default Detailed