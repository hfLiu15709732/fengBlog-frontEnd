import style from "../styles/componentsStyle/Header.module.css"
import { Button, Dropdown, Input,Select} from "antd"
import React,{useState} from "react"
import { DownOutlined} from '@ant-design/icons';
import {MoreApp,}from '@icon-park/react';
import '@icon-park/react/styles/index.css';
import Link from "next/link";
import { useRouter } from "next/router";
const { Option } = Select;
import Image from "next/image";

function Header(){



    const route=useRouter();




     let changeRouter=(value)=>{
        return(event)=>{
            console.log(value);
            route.push(`/list/?kind=${value}`)

        }

      }


      let goHome=()=>{
        route.push("/")
      }




      const items = [
        {
          key: '20',
          label: (
            <Link href="/list/?kind=2&column=所有专栏">
              前端笔记模块
            </Link>
          ),
        },
        {
          key: '21',
          label: (
            <Link href="/list/?kind=1">
              技术分享模块
            </Link>
          ),
        },
        {
          key: '22',
          label: (
            <Link href="/list/?kind=3">
              生活分享模块
            </Link>
          ),
        },
        {
          key: '23',
          label: (
            <Link href="/websiteCli">
              更多探索模块
            </Link>
          ),
        },
      ];

      const handleToColumn=(value)=>{
        route.push(`/list/?kind=2&column=${value}`)
      }

      const toWebsite=()=>{route.push("/websiteCli")}



      



      
    return(
        <div className={style.header}>
            <div className={style.panel}>
                <div className={style.naviLeft} >
                    <div className={style.logo} onClick={goHome}>
                      hfLiu.com
                    </div>
                    <span className={style.logoDes}>技术&nbsp;生活分享站</span>
                </div>
                <div className={style.naviRight}>
                        {/* <Search theme="outline" size="18" fill="#ffffff" strokeWidth={3} strokeLinecap="square" className={style.searchIcon}/>
                        <Input placeholder={"搜索你的Todo"} className={style.iptTop} >
                        </Input> */}
                  
                    <Button type="text" className={style.commonBtn}  onClick={changeRouter(1)}>
                    技术分享
                    </Button>
                    &nbsp;
                    <Button type="text"  onClick={changeRouter(3)} className={style.commonBtn} >
                    生活分享
                    </Button>
                    &nbsp;
                    &nbsp;
                    &nbsp;

                    <Select defaultValue={"前端笔记"} size="normal"
                    style={{fontWeight:700,color:"#fff"}} onChange={handleToColumn} className={style.commonBtn}>
                      <Option key="所有专栏" value="所有专栏" ></Option>
                      <Option key="HTML" value="HTML"></Option>
                      <Option key="CSS" value="CSS"></Option>
                      <Option key="JavaScript" value="JavaScript"></Option>
                      <Option key="后台开发" value="后台开发"></Option>
                      <Option key="数据库" value="数据库"></Option>
                      <Option key="框架学习" value="框架学习"></Option>
                      <Option key="Http网络" value="Http网络"></Option>

                    </Select>
                    &nbsp;
                    &nbsp;
                    &nbsp;

                    <Select defaultValue={"更多探索"} size="normal" 
                    style={{fontWeight:700,color:"#fff"}} onChange={toWebsite} className={style.commonBtn}>
                      <Option key="网站建设" value="网站建设" ></Option>
                      <Option key="等待开发" value="等待开发" disabled ></Option>
                      <Option key="等待开发" value="等待开发" disabled ></Option>

                    </Select>

                    <Dropdown menu={{items,}}placement="bottomLeft" arrow className={style.flexTarget}>
                            <Button type="text" style={{color:"#fff"}} >
                              <MoreApp theme="outline" size="22" fill="#fff" strokeWidth={3} strokeLinecap="square"/><DownOutlined />
                            </Button>
                    </Dropdown>
                </div>
            </div>
        </div>
    )

}
export default Header