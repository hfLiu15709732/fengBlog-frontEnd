import style from "../styles/componentsStyle/Footer.module.css"
function Footer(){
    return(
        <div className={style.footerDiv}>
            <div>峰哥博客-----hfLiu.com</div>
            <div>2.0&nbsp;&nbsp;Beta版本</div>
        </div>
    )

}

export default Footer